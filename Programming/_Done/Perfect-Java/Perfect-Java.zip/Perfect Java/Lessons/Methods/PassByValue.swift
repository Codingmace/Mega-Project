//
//  PassByValue.swift
//  Perfect Java
//
//  Created by Michael Ross on 2/8/21.
//

import SwiftUI

struct PassByValue: View {
    var body: some View {
        Text("This lesson is not complete yet, check back later")
    }
}

struct PassByValue_Previews: PreviewProvider {
    static var previews: some View {
        PassByValue()
    }
}
