//
//  Scopes.swift
//  Perfect Java
//
//  Created by Michael Ross on 2/8/21.
//

import SwiftUI

struct Scopes: View {
    var body: some View {
        Text("This lesson is not complete yet, check back later")
    }
}

struct Scopes_Previews: PreviewProvider {
    static var previews: some View {
        Scopes()
    }
}
