package ND;


import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class prob10 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob10.txt"));
        int n = scan.nextInt();
        for (int i = 0; i < n; i++) {
            int t = scan.nextInt(); // Top
            int h = scan.nextInt(); // Height
            int sum = 0;
            System.out.println("N An");
            for (int q = 0; q < 20; q++) {
                System.out.println(q + " " + q * q);
            }
            System.out.println(sum + " liters");
        }
    }

}
