package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */

/* Range is 1 - 100 */
public class Prob04 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob04.txt"));
        int n = scan.nextInt();
        while (n != 0) {

            n = scan.nextInt();
        }
    }
}
