# Privacy Policy

Perfect Java does not store or collect any data from any users. This app purely displays pre-written educational content, without connecting to the internet for any purpose. No user data is accessed, collected, or stored.
