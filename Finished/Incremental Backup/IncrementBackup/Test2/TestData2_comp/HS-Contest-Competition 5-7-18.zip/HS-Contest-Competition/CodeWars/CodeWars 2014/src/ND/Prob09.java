package ND;


import java.io.File;
import java.math.BigInteger;
import java.util.Scanner;

/**
 * @author Master Ward
 */
public class Prob09 {

    public static void main(String[] args) throws Exception {
//        Problem: Goldbach's Conjunction
//        Difficulty: Medium
//        Subject: Math, Prime
//        The other return is very unstable but works Sometimes
        Scanner scan = new Scanner(new File("prob09.txt"));
        int a = scan.nextInt();
        while (a != 0) {
            BigInteger b = new BigInteger(a + "");
            BigInteger b1 = b.divide(BigInteger.valueOf(2));
            BigInteger b2 = b.subtract(b1);
            while (!(isPrime(b1) && isPrime(b2))) {
                b1 = b1.subtract(BigInteger.ONE);
                b2 = b.subtract(b1);
//                System.out.println(b1 + " "+ b2);
            }
            System.out.println(b1.intValue() + " + " + b2.intValue() + " = " + a);
//            System.out.println(b1.intValue());
//            System.out.println(b1.isProbablePrime(a)); // Checks if B is prime
//            System.out.println(b.nextProbablePrime()); // Gets the next prime number
//            System.out.println(BigInteger.probablePrime(a, random));
            a = scan.nextInt();
        }
    }

    private static boolean isPrime(BigInteger b1) {
        int b = b1.intValue();
        for (int i = 2; i < b; i++) {
            if (b % i == 0) {
                return false;
            }
        }
        return true;
//        return b1.isProbablePrime(2);
    }
}
