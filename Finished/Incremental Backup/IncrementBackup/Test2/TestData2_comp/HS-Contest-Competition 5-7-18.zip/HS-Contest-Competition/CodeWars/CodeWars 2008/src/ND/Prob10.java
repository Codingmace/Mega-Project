package ND;

import java.io.File;
import java.util.Scanner;

/**
 * Not Done
 *
 * @author Master Ward
 */
public class Prob10 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob10.txt"));
        int s1x = scan.nextInt(); // Start 1 x
        int s1y = scan.nextInt(); // Start 1 y
        int e1x = scan.nextInt(); // End 1 x
        int e1y = scan.nextInt(); // End 1 y        
        int s2x = scan.nextInt(); // Start 2 x
        int s2y = scan.nextInt(); // Start 2 y
        int e2x = scan.nextInt(); // End 2 x
        int e2y = scan.nextInt(); // End 2 y
        while (s1x != 0 && s1y != 0 && e1x != 0 && e1y != 0 && s2x != 0 && s2y != 0 && e2x != 0 && e2y != 0) {

        }
    }
}
