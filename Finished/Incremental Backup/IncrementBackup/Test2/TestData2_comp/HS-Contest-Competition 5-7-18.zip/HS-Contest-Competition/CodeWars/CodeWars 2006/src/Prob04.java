

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
/* Couldn't test because there was no input file given */
public class Prob04 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob04.txt"));
        int n = scan.nextInt();
        while(n!= 0) {
            
            n = scan.nextInt();
        }

    }

}
