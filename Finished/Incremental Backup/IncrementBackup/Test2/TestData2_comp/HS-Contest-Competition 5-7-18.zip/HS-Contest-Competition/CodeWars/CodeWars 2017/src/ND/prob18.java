package ND;

import java.util.*;
import java.io.*;

/**
 * @author Master Ward
 */
public class prob18 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob18.txt"));

    }

}
