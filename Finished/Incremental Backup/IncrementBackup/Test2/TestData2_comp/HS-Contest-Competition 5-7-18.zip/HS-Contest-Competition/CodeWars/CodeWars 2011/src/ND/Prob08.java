package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob08 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob07.txt"));
        String a = scan.nextLine();
        int nc = 0;
        int oc = 0;
        while (!"END 0".equals(a)) {
            String b[] = a.split("\\s+");
            nc = oc;
            if ("SYNC".equals(b[0])) {
                System.out.println("Synchronize");
            } else if ("OPEN".equals(b[0])) {
                oc = (17 * Integer.parseInt(b[1]) + 91) % 256;
                if (nc == oc) {
                    System.out.println("INVALID");
                } else {
                    System.out.println("UNLOCK");
                }
            }
            System.out.println(nc + " " + oc);
            a = scan.nextLine();
        }
    }

}
