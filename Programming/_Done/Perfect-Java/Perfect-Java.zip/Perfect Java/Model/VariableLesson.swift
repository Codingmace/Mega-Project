//
//  VariableLesson.swift
//  Perfect Java
//
//  Created by Michael Ross on 10/28/20.
//

import SwiftUI

struct VariableLesson: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct VariableLesson_Previews: PreviewProvider {
    static var previews: some View {
        VariableLesson()
    }
}
