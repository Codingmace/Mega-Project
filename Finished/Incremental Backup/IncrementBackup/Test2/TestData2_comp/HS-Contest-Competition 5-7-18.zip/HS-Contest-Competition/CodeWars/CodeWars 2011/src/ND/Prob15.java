package ND;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob15 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob15.txt"));
        int a = scan.nextInt();
        scan.nextLine();
        ArrayList<String> ar = new ArrayList();
        for (int i = 0; i < a; i++) {
            ar.add(scan.nextLine());
        }
        int b = scan.nextInt();
        scan.nextLine();
        for (int i = 0; i < b; i++) {
            String c = scan.nextLine();
            char d = c.charAt(0);
            if (d == 'a') { // Add
                if (ar.size() > a) {
                    ar.add(c.split(" ")[2]);
                } else {
//                    String ty[] = c.split(" ");
                    ar.add(Integer.parseInt(c.charAt(2) + ""), (ar.get(Integer.parseInt(c.charAt(2) + "")) + c.substring(4)));
                }
            } else if (d == 'd') { // Delete
                int te = Integer.parseInt(c.substring(c.length() - 1));
                if (te > ar.size()) {
                    ar.remove(0);
                } else {
                    ar.remove(te);
                }
            } else if (d < '9') { // Specific Line
                String e[] = c.split("/");
            } else {
                String e[] = c.split("/");
                System.out.println(Arrays.toString(e));
                for (int o = 0; o < ar.size(); o++) {
                    if (ar.get(o).contains(e[1].trim())) {
                        ar.set(o, ar.get(o).replaceAll(e[1], e[2]));
                    }
                }
            }
        }
        for (String g : ar) {
            System.out.println(g);
        }
    }
}
