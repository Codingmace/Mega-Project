package ND;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * Not Done
 *
 * @author Master Ward
 */
public class Prob14 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob14.txt"));
        String a = scan.nextLine();
        LinkedList<String> ll = new LinkedList(); // Acot List to movie
        ArrayList<LinkedList<String>> act = new ArrayList(); // Actors List
        HashSet hs = new HashSet(); // Actor name List
        while (!"[ACTORS]".equals(a)) {
            String m = scan.next(); // Movie
            String b[] = scan.nextLine().split("\\s+");
            for (String c : b) {
                if (hs.contains(c)) {
//                    Get the index of it in act
                } else {
                    hs.add(c);
                }
            }
        }
    }

}
