
/**
 *
 * @author Master Ward
 */
public class Prob00 {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
