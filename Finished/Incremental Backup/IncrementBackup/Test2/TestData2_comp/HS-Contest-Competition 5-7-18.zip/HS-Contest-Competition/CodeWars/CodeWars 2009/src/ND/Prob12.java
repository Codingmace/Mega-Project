package ND;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob12 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob12.txt"));
        String a = scan.nextLine();
        String fin = "";
        while (!"###".equals(a.trim())) {
            fin += a.toUpperCase() + " ";
            a = scan.nextLine();
        }
        String fina = fin.replaceAll("[^A-Z']+", " ");
        String b[] = fina.split("\\s+");
        HashMap<String, Integer> hs = new HashMap();
        for (int i = 0; i < b.length; i++) {
            if (hs.containsKey(b[i])) {
                hs.put(b[i], hs.get(b[i]) + 1);
            } else {
                hs.put(b[i], 1);
            }
        }
        Object c[] = hs.values().toArray();
        Arrays.sort(c);
        int min = (int) (c[c.length - 6]);
        for (int i = 0; i < b.length; i++) {
            if (hs.containsKey(b[i])) {
                if (hs.get(b[i]) < min) {
                    hs.remove(b[i]);
                }
            }
        }
        int con = 0;
        System.out.println(Arrays.toString(c));
        System.out.println(hs.values());
        System.out.println(hs.keySet());
    }
}
