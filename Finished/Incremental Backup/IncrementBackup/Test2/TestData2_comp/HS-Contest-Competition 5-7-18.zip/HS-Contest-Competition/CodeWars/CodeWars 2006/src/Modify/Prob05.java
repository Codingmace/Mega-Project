package Modify;

import java.io.File;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Master Ward
 */
public class Prob05 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob05.txt"));

        Pattern p = Pattern.compile("\\d+");
        Matcher m = null;
        int numApps = 0;

        //Create new Server object
        HPServer Server = new HPServer(scan.nextLine());

        numApps = Integer.parseInt(scan.nextLine());
        //Add Applications to our Server
        for (int i = 1; i <= numApps; i++) {
            Server.addApp(scan.nextLine());
        }

        if (Server.overloaded) {
            System.out.println("No");
        } else {
            System.out.println("Yes");
        }
        System.out.printf("%.2f%s CPU\n", Server.getCPU(), "%");
        System.out.printf("%.2f%s memory\n", Server.getRAM(), "%");

        scan.close();
        System.exit(0);
    }

}

class HPServer {

    private String model;
    private int speed;
    private int ram;
    private int cpuload = 0;
    private int ramload = 0;
    public boolean overloaded = false;

    public HPServer(String serverinfo) {

        // Split line into it's  attributes (model, speed and ram)
        String[] attrib = serverinfo.split(",", 2);
        // Set model name
        model = attrib[0];

        // Set CPU speed
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(attrib[1]);
        m.find();
        speed = Integer.parseInt(m.group());

        // Set RAM capacity
        m.find();
        ram = Integer.parseInt(m.group());

    }

    public void addApp(String appinfo) {
        // Split line into it's attributes (application, speed and ram)
        String[] attrib = appinfo.split(",", 2);

        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(attrib[1]);

        // Add application cpuload
        m.find();
        cpuload += Integer.parseInt(m.group());
        if (cpuload > speed) {
            overloaded = true;
        }

        // Add application ram requirements
        m.find();
        ramload += Integer.parseInt(m.group());
        if (ramload > ram) {
            overloaded = true;
        }
    }

    public double getCPU() {
        return (Math.round(((double) cpuload / (double) speed) * 10000)) / (double) 100;
    }

    public double getRAM() {
        return (Math.round(((double) ramload / (double) ram) * 10000)) / (double) 100;
    }

}
