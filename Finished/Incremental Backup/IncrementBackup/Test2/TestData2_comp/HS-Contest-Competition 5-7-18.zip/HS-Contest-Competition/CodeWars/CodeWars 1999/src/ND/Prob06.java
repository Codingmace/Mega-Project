package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */

/* Need to find optimum and don't know how to do that */
public class Prob06 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob06.txt"));
        while (scan.hasNext()) {
            double v = scan.nextDouble(); // Volume
            System.out.print("Volume=" + v + " in^3,");
            double vm = v / 3.14159;
            System.out.println("VolumeMod= " + vm + " in^3");
        }
    }
}
