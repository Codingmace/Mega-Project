//
//  Constants.swift
//  Perfect Java
//
//  Created by Michael Ross on 10/22/20.
//

import Foundation
import UIKit

struct Constants {
    
    
    
}
