package ND;

import java.io.File;
import java.util.Scanner;

/**
 * @author Master Ward
 */
public class Prob10 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob10.txt"));
        String a = scan.nextLine();
        while (!"0 0 0 0 0 0 0 0 0 0".equals(a)) {
            String b[] = a.split("\\s");
            double a1 = Double.parseDouble(b[0]);
            double db[] = doublify(b);
        }
    }

    private static double[] doublify(String a[]) {
        double x[] = new double[a.length];
        for (int i = 0; i < a.length; i++) {
            x[i] = Double.parseDouble(a[i]);
        }
        return x;
    }
}
