
/**
 *
 * @author Ryan Talbot
 */
public class Prob00 {

    public static void main(String[] args) {
        System.out.print("G");
        System.out.print("o");
        System.out.print(" ");
        System.out.print("R");
        System.out.print("a");
        System.out.print("m");
        System.out.print("s");
        System.out.print(" ");
        System.out.print("G");
        System.out.print("o");
        System.out.print("!");
        System.out.print("\n");
    }
}
