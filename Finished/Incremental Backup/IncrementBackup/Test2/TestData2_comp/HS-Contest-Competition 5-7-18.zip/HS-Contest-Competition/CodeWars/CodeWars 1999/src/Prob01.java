
/**
 *
 * @author Master Ward
 */
public class Prob01 {

    public static void main(String[] args) throws Exception {
        System.out.println("The code is ran in c and all you do is put it in a c file and run it.");
    }
}
