package Modify;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob09 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob09.txt"));
        List<String> wordlist = new ArrayList<>();

        String alphabet = scan.next(); // Get Random Alphabet

        // Build our list of words to sort
        while (scan.hasNext()) {
            wordlist.add(scan.next());
        }
        Collections.sort(wordlist, new RandomSortComparator(alphabet));

        /* Print sortes List */
        Iterator it = wordlist.listIterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        scan.close();
    }
}

class RandomSortComparator implements Comparator {

    private String alphabet = null;

    // Constructor to initialize our alphabet
    public RandomSortComparator(String alphabet) {
        this.alphabet = alphabet;
    }

    @Override
    public int compare(Object o1, Object o2) {
        String s1 = o1.toString().toUpperCase();
        String s2 = o2.toString().toUpperCase();
        int i = 0;

        while (i < s1.length() && i < s2.length()) {
            // If the letters match, move to next letter
            if (alphabet.indexOf(s1.charAt(i)) == alphabet.indexOf(s2.charAt(i))) {
                i++;
            } else {
                // Return neg if o1 < o2, or positive if o1 > o2
                return alphabet.indexOf(s1.charAt(i)) - alphabet.indexOf(s2.charAt(i));
            }
        }
        // If we are here, then the first x letters of both words match.
        // Return neg if o1 is shorter than o2, positive if o1 is longer than o2, and 0 of they are equal
        return s1.length() - s2.length();
    }
}
