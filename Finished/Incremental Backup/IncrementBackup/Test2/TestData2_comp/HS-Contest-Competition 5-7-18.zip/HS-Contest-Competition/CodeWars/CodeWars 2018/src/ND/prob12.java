package ND;


import java.io.File;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
/* Add in a parameter when there are duplicate cases */
public class prob12 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob12.txt"));
        int c = scan.nextInt(); // Cases Currently
        scan.nextLine();
        String ac[] = new String[c];
        for (int i = 0; i < c; i++) {
            ac[i] = scan.nextLine();
        }
        Arrays.sort(ac);
        int p = scan.nextInt(); // Cases Considering
        String mod[] = new String[c]; // Modified for chars only
        for (int i = 0; i < c; i++) {
            mod[i] = charify(ac[i]);
//            System.out.println(ac[i] + "   " + mod[i]);
        }
        String pc[] = new String[p];
        for (int i = 0; i < p; i++) {
            pc[i] = scan.nextLine();
        }
        for (int i = 0; i < p; i++) {
            for (int o = 0; o < c; o++) {
                if (!mod[o].equals("")) {

                }
            }
        }

    }

    /* Returns a sorted String */
    public static String charify(String a) {
        char ch[] = a.toCharArray();
        Arrays.sort(ch);
        String fin = "";
        for (char c : ch) {
            fin += c;
        }
        return fin;
    }
}
