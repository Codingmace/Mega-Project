
/**
 *
 * @author Master Ward
 */
public class Prob01 {

    public static void main(String[] args) {
        System.out.println("HEY what's up note that is always manditory before the competition.");
        System.out.println("WE are High school with teammates:");
        System.out.println("Who Knows\nWhats on second\nBatman");
    }
}
