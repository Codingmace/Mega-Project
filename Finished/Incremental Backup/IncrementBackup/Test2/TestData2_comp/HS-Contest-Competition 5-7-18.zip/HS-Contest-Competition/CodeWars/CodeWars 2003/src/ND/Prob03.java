package ND;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
/* Haven't solved Only printing Saturday */
public class Prob03 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob03.txt"));
        int month = scan.nextInt();
        int day = scan.nextInt();
        String months[] = {"", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thusday", "Friday", "Saturday"};
        Calendar c = Calendar.getInstance();
//        Date d = new Date();
//        d.setMonth(month);
//        d.setDay(day);
//        d.setYear(2003);
        c.clear();
        c.set(2003, month, day);
        System.out.println(month + " " + day);
        int dow = (c.DAY_OF_WEEK) - 1;
        System.out.println(Calendar.DAY_OF_WEEK);
        System.out.println("Date " + c.DATE);
        System.out.println(months[month] + " " + day + ", 2003 is a " + days[dow]);
//        System.out.println(c.get(Calendar.DAY_OF_MONTH));
//        System.out.println(c.get(Calendar.DAY_OF_WEEK));
//        System.out.println(c.get(Calendar.DATE));
//        System.out.println(c.get(Calendar.MONTH));

    }
}
