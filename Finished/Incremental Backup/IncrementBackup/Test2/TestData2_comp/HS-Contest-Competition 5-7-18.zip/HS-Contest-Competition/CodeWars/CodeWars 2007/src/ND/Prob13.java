package ND;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob13 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob13.txt"));
        int a = scan.nextInt();
        scan.nextLine();
        for (int i = 0; i < a; i++) {
            String b = cap(scan.nextLine()); // Top
//            System.out.println(b);
            String c = cap(scan.nextLine()); // Middle
            String d = cap(scan.nextLine()); // Bottom
            ArrayList<String> ar = new ArrayList();
            String temp = "";
            for (int io = 0; io < 27; io++) {
//                try {
                temp += b.charAt(io);
                temp += c.charAt(io);
                temp += d.charAt(io);
//                } catch (StringIndexOutOfBoundsException e) {
//                }
                if (io % 3 == 0) {
                    ar.add(temp);
                    System.out.println(temp);
                    temp = "";
                }
            }
            for (int ip = 0; ip < ar.size(); ip++) {
                String cur = ar.get(ip);
//                String cur = ar.get(ip).trim();
                switch (cur) {
                    case " ||":
                        System.out.print("1");
                        break;
                    case "  |___ |":
                        System.out.print("2");
                        break;
                    case "___ ||":
                        System.out.print("3");
                        break;
                    case " |  _  ||":
                        System.out.print("4");
                        break;
                    case " | ___  |":
                        System.out.print("5");
                        break;
                    case "||___  |":
                        System.out.print("6");
                        break;
                    case "_   || ||":
                        System.out.print("7");
                        break;
                    case "___ || |":
                        System.out.print("8");
                        break;
                    case " __ ||":
                        System.out.print("9");
                        break;
                    default:
                        System.out.println("Broken " + cur);
                        break;
                }
//                System.out.println(ar.get(ip));
            }
            System.out.println();
        }
    }

    public static String cap(String a) {
        int time = 27 - a.length();
        for (int i = 0; i < time; i++) {
            a += " ";
        }
        return a;
    }
}
