package ND;

import java.awt.Point;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author Master Ward
 */
public class Prob17 {

    private static int turns;
    private static List<Point> points;

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob17.txt"));
        String a = scan.nextLine();
        int lowX;
        int lowY;
        while (!"# #".equals(a)) {
            String[] parts = a.split(" ");
            String direction = parts[0];
            String endPoint = parts[1];
            char cEndPoint = endPoint.charAt(0);
            int iEndPoint = 0;
            if (cEndPoint > 'A') {
                iEndPoint = (cEndPoint - 'A') + 10;
            } else {
                iEndPoint = Integer.parseInt(endPoint);
            }
            turns = 0;
            points = new ArrayList<>();
            lowX = 0;
            lowY = 0;
            String path = printPath(direction, iEndPoint);
            int height = calculateHeight(lowY);
            int width = calculateWidth(lowX);
            char grid[][] = new char[height][width];
            for (int r = 0; r < height; r++) {
                grid[r] = new char[width];
                for (int c = 0; c < width; c++) {
                    grid[r][c] = '.';
                }
            }
            Point start = new Point((-1 * lowX), (-1 * lowY));
            grid[start.y][start.x] = '0';
            Point current = new Point(start);
            for (int p = 1; p < path.length(); p++) {
                char c = path.charAt(p);
                if (c == '\\') {
                    current.x += 1;
                    current.y += 1;
                    grid[current.y][current.x] = c;
                    current.x += 1;
                    current.y += 1;
                } else if (c == '-') {
                    current.x -= 1;
                    grid[current.y][current.x] = c;
                    current.x -= 1;
                    grid[current.y][current.x] = c;
                    current.x -= 1;
                    grid[current.y][current.x] = c;
                    current.x -= 1;
                    p += 2;
                } else if (c == '/') {
                    current.y -= 1;
                    current.x += 1;
                    grid[current.y][current.x] = c;
                    current.y -= 1;
                    current.x += 1;
                } else {
                    grid[current.y][current.x] = c;
                }
            }
            for (int r = 0; r < grid.length; r++) {
                for (int c = 0; c < grid[r].length; c++) {
                    System.out.print(grid[r][c]);
                }
                System.out.println();
            }
            System.out.println();

            a = scan.nextLine();
        }
    }

    private static String printPath(String startDir, int end) {
        String direction = startDir;
        int changeDirectionCount = 0;
        int changeDirectionIncr = 2;
        StringBuilder sb = new StringBuilder();
        Point currentLocation = new Point(0, 0);
        for (int index = 0; index < end; index++) {
            points.add(currentLocation);
            currentLocation = new Point(currentLocation);
            if (index > 9) {
                char c = (char) ('A' + (index - 10));
                sb.append(c);
            } else {
                sb.append(index);
            }
            if (direction.equals("-")) {
                sb.append(direction);
                sb.append(direction);
                sb.append(direction);
                currentLocation.x -= 4;

            } else {
                sb.append(direction);

                if (direction.equals("/")) {
                    currentLocation.x += 2;
                    currentLocation.y -= 2;
                } else if (direction.equals("\\")) {
                    currentLocation.x += 2;
                    currentLocation.y += 2;
                }
            }
            if (index == changeDirectionCount) {
                direction = getNextDirection(direction);
                changeDirectionCount += changeDirectionIncr;
                changeDirectionIncr++;
                turns++;
            }

        }
        points.add(currentLocation);
        if (end > 9) {
            char c = (char) ('A' + (end - 10));
            sb.append(c);
        } else {
            sb.append(end);
        }
        return sb.toString();
    }

    private static int calculateHeight(int lowY) {
        int height = 0;
        int highY = 0;
        for (Point p : points) {
            if (p.y < lowY) {
                lowY = p.y;
            }
            if (p.y > highY) {
                highY = p.y;
            }
        }
        height = (-1 * lowY) + highY + 1;
        return height;
    }

    private static int calculateWidth(int lowX) {
        int width = 0;
        int highX = 0;
        for (Point p : points) {
            if (p.x < lowX) {
                lowX = p.x;
            }
            if (p.x > highX) {
                highX = p.x;
            }
        }
        width = (-1 * lowX) + highX + 1;
        return width;
    }

    private static String getNextDirection(String direction) {
        String nextDir = null;
        if (direction.equals("/")) {
            nextDir = "\\";
        } else if (direction.equals("\\")) {
            nextDir = "-";
        } else if (direction.equals("-")) {
            nextDir = "/";
        }
        return nextDir;
    }

}
