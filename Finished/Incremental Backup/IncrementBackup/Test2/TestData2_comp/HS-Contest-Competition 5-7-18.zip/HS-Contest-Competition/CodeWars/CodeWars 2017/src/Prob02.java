
import java.util.*;
import java.io.*;

/**
 *
 * @author Ryan Talbot
 */
public class Prob02 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob02.txt"));
        System.out.println((scan.nextInt() * scan.nextInt()));
    }

}
