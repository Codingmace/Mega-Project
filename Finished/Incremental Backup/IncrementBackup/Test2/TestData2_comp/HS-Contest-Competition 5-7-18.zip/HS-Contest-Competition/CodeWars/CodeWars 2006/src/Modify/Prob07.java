package Modify;

import java.io.File;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Master Ward
 */
public class Prob07 {

    public static char grid[][] = new char[9][9];

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob07.txt"));
        for (int i = 0; i < grid[0].length; i++) {
            grid[i] = scan.nextLine().toCharArray();
        }
        if (check()) {
            System.out.println("CORRECT");
        } else {
            System.out.println("INCORRECT");
        }
    }

    /* Checks the grid */
    private static boolean check() {
        /* Checks rows */
        for (int o = 0; o < 9; o++) {
            boolean numbers[] = new boolean[9]; // If number exist
            for (int i = 0; i < 9; i++) {
                int point = grid[o][i] - 49; // Checking point
                numbers[point] = !numbers[point];
            }
            if (!validation(numbers)) {
                System.out.println("The rows are the problem");
                return false;
            }
        }
        /* Checks columns */
        for (int o = 0; o < 9; o++) {
            boolean numbers[] = new boolean[9]; // If number exist
            for (int i = 0; i < 9; i++) {
                int point = grid[i][o] - 49; // Checking point
                numbers[point] = !numbers[point];
            }
            if (!validation(numbers)) {
                System.out.println("The columns are the problem");
                return false;
            }
        }
        /* Need to fix this part */

        for (int i = 0; i < 9; i += 3) {
            for (int j = 0; j < 9; j += 3) {
                // Begin a new Matrix
                Set matrix = new HashSet<>();
                for (int x = i; x < i + 3; x++) {
                    for (int y = j; y < j + 3; y++) {
                        if (!matrix.add(grid[x][y])) {
                            return false;
                        }
                    }
                }
            }
        }
        /* UP to here is coppied */
        for (int o = 0; o < 3; o++) { // Has the three column of boxes
            boolean numbers[] = new boolean[9]; // If number exist
            for (int i = 0; i < 3; i++) { // Check 3 boxes on each row

            }
            if (!validation(numbers)) {
                System.out.println("The boxes are the problem");
                return false;
            }
        }

        return true;
    }

    /* Checks to see if the whole boolean array is true */
    public static boolean validation(boolean[] array) {
        for (boolean b : array) {
            if (!b) {
                return false;
            }
        }
        return true;
    }

}
