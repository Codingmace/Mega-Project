//
//  Primitive02.swift
//  Perfect Java
//
//  Created by Michael Ross on 11/6/20.
//

import SwiftUI

struct Primitive02: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct Primitive02_Previews: PreviewProvider {
    static var previews: some View {
        Primitive02()
    }
}
