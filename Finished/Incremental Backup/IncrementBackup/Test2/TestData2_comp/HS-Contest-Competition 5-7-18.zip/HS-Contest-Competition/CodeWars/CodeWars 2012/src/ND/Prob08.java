package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob08 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob08.txt"));
        String a = scan.nextLine();
        String fin = "";
        while (!"###".equals(a)) {
            fin += a;
            a = scan.nextLine();
        }
        char ch[] = fin.toUpperCase().toCharArray();
        char cd[] = new char[26];
        for (int i = 0; i < ch.length; i++) {
            cd[ch[i] - 'A']++;
        }
    }
}
